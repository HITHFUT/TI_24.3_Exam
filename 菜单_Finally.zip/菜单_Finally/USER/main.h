#ifndef __MAIN_H
#define __MAIN_H	 
#include "sys.h"

void lock(void);		
void computer(void);
void electric_t(void);	

				    
#endif

